# @zhixiaoji/api-sdk-web

知晓记 Web 端 SDK - 专为 Vue3/Web 应用设计的 API 客户端

## 安装

```bash
npm install @zhixiaoji/api-sdk-web
```

## 使用方式

### 多服务路由（推荐）

项目采用微服务架构，通过 `authBaseURL` / `coreBaseURL` 配置路由分发：

```typescript
import { createVue3ApiClient } from '@zhixiaoji/api-sdk-web';
import { useAuthStore } from '@/stores/auth';

const api = createVue3ApiClient({
  baseURL: 'http://192.168.16.129:12302/api/v1',       // 默认走 core-service
  authBaseURL: 'http://192.168.16.129:12301/api/v1',   // /auth/* 走 auth-service
  storage: 'pinia',
  store: useAuthStore(),
  onAuthError: () => router.push('/login'),
});
```

**路由规则**：

| 路径前缀 | 代理服务 | 说明 |
|----------|----------|------|
| `/auth/*` | auth-service (12301) | 登录、用户管理 |
| `/workflow/*` | core-service (12302) | 工作流管理 |
| 其他路径 | core-service (12302) | 默认 |

### Vue3 + Pinia（单服务）

```typescript
import { createVue3ApiClient } from '@zhixiaoji/api-sdk-web';
import { useAuthStore } from '@/stores/auth';

const api = createVue3ApiClient({
  baseURL: 'https://api.zhixiaoji.com/api/v1',
  storage: 'pinia',
  store: useAuthStore(),
  onAuthError: () => router.push('/login'),
});

// 登录
const result = await api.auth.adminLogin({ username: 'admin', password: 'xxx' });
api.setToken(result.data.accessToken);

// 获取用户信息
const profile = await api.auth.getProfile();
```

### 普通 Web 应用

```typescript
import { createApiClient } from '@zhixiaoji/api-sdk-web';

const api = createApiClient({
  baseURL: 'https://api.zhixiaoji.com/api/v1',
});
```

## 调试日志

SDK 提供调试日志功能，默认关闭。开启后会打印每个 API 请求的请求头、请求体和返回结果。

### 方式一：初始化时开启

```typescript
const api = createVue3ApiClient({
  baseURL: 'https://api.zhixiaoji.com/api/v1',
  enableLog: true,  // 开启调试日志
});
```

### 方式二：动态开启/关闭

```typescript
// 开启日志
api.setLogEnabled(true);

// 关闭日志
api.setLogEnabled(false);
```

### 日志输出格式

```
[SDK Request] GET https://api.zhixiaoji.com/api/v1/auth/me
[SDK Headers] {
  "Content-Type": "application/json",
  "Authorization": "Bearer eyJhbGciOiJIUzI1NiIs..."
}

[SDK Response] GET https://api.zhixiaoji.com/api/v1/auth/me
[SDK Result] {
  "code": 0,
  "data": {
    "id": "xxx",
    "nickname": "用户昵称"
  },
  "message": "ok"
}
```

## API 详细说明

### 认证相关

#### `auth.adminLogin(data)`

管理后台登录

**请求参数**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| username | string | 是 | 用户名 |
| password | string | 是 | 密码 |

**返回数据**：

| 字段 | 类型 | 说明 |
|------|------|------|
| accessToken | string | JWT Token |
| refreshToken | string | 刷新 Token |
| expiresIn | number | 过期时间（秒） |
| admin | object | 管理员信息 |
| admin.id | string | 管理员 ID |
| admin.username | string | 用户名 |
| admin.role | string | 角色：super_admin / editor / viewer |

**示例**：

```typescript
const result = await api.auth.adminLogin({
  username: 'admin',
  password: 'password'
});
// result.data.accessToken
// result.data.admin.id
```

---

#### `auth.refreshToken(data)`

刷新 Token

**请求参数**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| refreshToken | string | 是 | 刷新 Token |

**返回数据**：

| 字段 | 类型 | 说明 |
|------|------|------|
| accessToken | string | 新 JWT Token |
| refreshToken | string | 新刷新 Token |
| expiresIn | number | 过期时间（秒） |

---

#### `auth.logout()`

退出登录

**返回数据**：`null`

---

#### `auth.getProfile()`

获取当前用户信息

**返回数据**：

| 字段 | 类型 | 说明 |
|------|------|------|
| id | string | 用户 ID |
| nickname | string \| null | 用户昵称 |
| avatarUrl | string \| null | 头像 URL |
| email | string \| null | 邮箱 |
| address | string \| null | 地址 |
| bio | string \| null | 个性签名 |
| gender | string \| null | 性别：male / female / other |
| birthday | string \| null | 生日，格式：YYYY-MM-DD |
| level | number | 用户等级 |
| points | number | 积分余额 |
| learnedCards | number | 已学习卡片数 |
| createdAt | string | 创建时间（ISO 8601） |
| lastActiveAt | string \| null | 最后活跃时间（ISO 8601） |

**示例**：

```typescript
const result = await api.auth.getProfile();
console.log(result.data.nickname);
console.log(result.data.email);
console.log(result.data.gender);  // 'male' | 'female' | 'other'
```

---

#### `auth.getAdminProfile()`

获取当前管理员信息

**返回数据**：

| 字段 | 类型 | 说明 |
|------|------|------|
| id | string | 管理员 ID |
| username | string | 用户名 |
| role | string | 角色：super_admin / editor / viewer |
| createdAt | string | 创建时间（ISO 8601） |

---

#### `auth.updateProfile(userId, data)`

更新用户信息

**请求参数**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| userId | string | 是 | 用户 ID |
| data | object | 是 | 更新数据 |
| data.nickname | string | 否 | 用户昵称，1-64 字符 |
| data.avatarUrl | string | 否 | 头像 URL，必须以 http:// 或 https:// 开头 |
| data.email | string | 否 | 邮箱地址 |
| data.address | string | 否 | 地址，1-256 字符 |
| data.bio | string | 否 | 个性签名 |
| data.gender | string | 否 | 性别：male / female / other |
| data.birthday | string | 否 | 生日，格式：YYYY-MM-DD |

**示例**：

```typescript
const result = await api.auth.updateProfile('user-uuid', {
  nickname: '新昵称',
  gender: 'male',
  birthday: '1990-01-01',
});
```

---

#### `auth.getUsers(params?)`

分页查询用户列表（管理员）

**请求参数**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| page | number | 否 | 页码，默认 1 |
| pageSize | number | 否 | 每页数量，默认 20 |
| keyword | string | 否 | 关键词搜索 |
| status | string | 否 | 状态筛选：normal / disabled |
| level | number | 否 | 等级筛选 |
| startDate | string | 否 | 注册开始日期 YYYY-MM-DD |
| endDate | string | 否 | 注册结束日期 YYYY-MM-DD |
| sortOrder | string | 否 | 排序：asc / desc |

---

#### `auth.updateUserStatus(userId, data)`

更新用户状态

**请求参数**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| userId | string | 是 | 用户 ID |
| data.status | string | 是 | 状态：normal / disabled |

---

### 工作流管理

> ⚠️ 工作流写接口需要通过后端 Core Service 代理调用，前端 SDK 提供完整的类型定义和接口封装。

#### `workflow.getProviderCount()`

获取供应商数量

**返回数据**：`{ count: number }`

---

#### `workflow.listProviders(params?)`

供应商列表（分页+搜索）

**请求参数**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| page | number | 否 | 页码，默认 1 |
| pageSize | number | 否 | 每页数量，默认 20 |
| status | string | 否 | 状态筛选 |
| keyword | string | 否 | 关键字搜索 |

**返回数据**：分页列表，类型 `WorkflowProvider`

| 字段 | 类型 | 说明 |
|------|------|------|
| id | string | 供应商 ID |
| name | string | 名称 |
| description | string \| null | 描述 |
| endpointUrl | string | 工作流访问 URL |
| authType | string | 鉴权方式：api_key / oauth2 / bearer_token / custom |
| authConfig | object \| null | 鉴权配置 |
| status | string | 状态 |

---

#### `workflow.getProvider(id)`

获取供应商详情

---

#### `workflow.createProvider(data)`

创建供应商（需 x-internal-key 鉴权）

---

#### `workflow.getProviderConfigs(providerId)`

获取供应商下的工作流配置列表

---

#### `workflow.getConfigCount()`

获取工作流配置数量

---

#### `workflow.listConfigs(params?)`

工作流配置列表（分页+多维度筛选）

**请求参数**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| page | number | 否 | 页码 |
| pageSize | number | 否 | 每页数量 |
| providerId | string | 否 | 按供应商筛选 |
| type | string | 否 | 工作流类型：outline_generation / image_generation / section_content_generation / teaching_video_generation |
| status | string | 否 | 状态筛选 |
| keyword | string | 否 | 关键字搜索 |

**返回数据**：分页列表，类型 `WorkflowConfig`

| 字段 | 类型 | 说明 |
|------|------|------|
| id | string | 配置 ID |
| providerId | string | 供应商 ID |
| provider | WorkflowProvider | 供应商详情 |
| type | WorkflowType | 工作流类型 |
| name | string | 配置名称 |
| outputMode | string | streaming / non_streaming |
| remoteWorkflowId | string \| null | 远程平台工作流 ID |
| nodeCount | number | 节点数量 |
| nodesConfig | LLMNodeConfig[] | 节点配置（含展开的 modelConfig） |
| status | string | 状态 |

---

#### `workflow.getConfig(id)`

获取工作流配置详情（含自动填充的模型信息）

---

#### `workflow.createConfig(data)`

创建工作流配置

**请求参数**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| providerId | string | 是 | 供应商 ID |
| type | WorkflowType | 是 | 工作流类型 |
| name | string | 是 | 配置名称 1-128 字符 |
| outputMode | string | 否 | streaming / non_streaming |
| nodeCount | number | 是 | 节点数量 |
| nodesConfig | LLMNodeConfigRequest[] | 是 | 节点配置列表 |
| status | string | 否 | active / inactive |

**LLMNodeConfigRequest**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| nodeIndex | number | 是 | 节点索引 |
| nodeName | string | 是 | 节点名称 |
| modelConfigId | string | 是 | 大模型配置 ID |
| systemPrompt | string | 否 | 系统提示词 |
| userPrompt | string | 否 | 用户提示词 |

---

#### `workflow.getConfigsByType(type)`

按类型获取工作流配置

---

#### `workflow.listModelConfigs(params?)`

大模型配置列表（分页+筛选）

**请求参数**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| page | number | 否 | 页码 |
| pageSize | number | 否 | 每页数量 |
| llmProvider | string | 否 | 按提供商筛选 |
| status | string | 否 | 状态筛选 |
| keyword | string | 否 | 关键字搜索 |

**返回数据**：类型 `WorkflowModelConfig`

| 字段 | 类型 | 说明 |
|------|------|------|
| id | string | 配置 ID |
| name | string | 配置名称 |
| llmProvider | string | 大模型提供商 |
| model | string | 模型型号 |
| apiKey | string | API Key |
| inputMaxTokens | number \| null | 输入最大 token |
| inputContextFields | string[] \| null | 输入上下文字段 |
| outputFormat | string \| null | 输出格式 |
| outputMaxTokens | number \| null | 输出最大 token |
| thinkingLevel | string \| null | 思考程度 |

---

#### `workflow.getModelConfig(id)`

获取大模型配置详情

---

#### `workflow.createModelConfig(data)`

创建大模型配置

**请求参数**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| name | string | 是 | 配置名称 1-128 字符 |
| llmProvider | string | 是 | 大模型提供商 1-64 字符 |
| model | string | 是 | 模型型号 1-64 字符 |
| apiKey | string | 是 | API Key 1-256 字符 |
| inputMaxTokens | number | 否 | 输入最大 token |
| inputContextFields | string[] | 否 | 输入上下文字段 |
| outputFormat | string | 否 | 输出格式 |
| outputMaxTokens | number | 否 | 输出最大 token |
| thinkingLevel | string | 否 | 思考程度 |

---

#### `workflow.updateModelConfig(id, data)`

更新大模型配置

---

#### `workflow.executeWorkflow(configId, data)`

执行工作流（异步，立即返回 taskId）

**请求参数**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| configId | string | 是 | 工作流配置 ID |
| data.inputParams | object | 是 | 工作流输入参数，如 `{topic: "Python基础"}` |

**返回数据**：`{ taskId: string }`

**示例**：

```typescript
const result = await api.workflow.executeWorkflow('config-uuid', {
  inputParams: { topic: 'Python基础' }
});
console.log(result.data.taskId);
```

---

#### `workflow.getExecutionTask(taskId)`

查询执行任务状态和结果

**返回数据**：类型 `WorkflowExecutionLog`

| 字段 | 类型 | 说明 |
|------|------|------|
| id | string | 记录 ID |
| configId | string | 配置 ID |
| taskId | string | 任务追踪 ID |
| inputParams | object | 输入参数 |
| status | string | pending / running / completed / failed |
| outputData | string \| null | 输出结果 (JSON string) |
| errorMessage | string \| null | 错误信息 |
| executionTimeMs | number \| null | 执行耗时 |
| createdAt | string | 创建时间 |
| updatedAt | string | 更新时间 |

---

#### `workflow.listExecutions(params?)`

执行历史列表

**请求参数**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| page | number | 否 | 页码 |
| pageSize | number | 否 | 每页数量 |
| configId | string | 否 | 按配置 ID 筛选 |
| status | string | 否 | 按状态筛选 |

---

## 版本历史

| 版本 | 日期 | 说明 |
|------|------|------|
| 0.1.1 | 2026-05 | 初始版本，包含 Auth 模块 8 个 API |
| 0.2.0 | 2026-05 | 新增 Workflow 模块（22 个 API） |
| 0.2.1 | 2026-05 | 类型整改（WorkflowType/ProviderType/baseUrl），新增 UPDATE/DELETE 方法 |
| 0.3.0 | 2026-05 | HttpClient 多服务路由支持（authBaseURL/coreBaseURL） |